// Change this to your live Railway URL after deploy.
// Example: "https://ecocomply-api.up.railway.app/api/audit"
window.ECOCOMPLY_API_URL = window.ECOCOMPLY_API_URL || "http://localhost:8000/api/audit";

(function () {
      const nav = document.getElementById("nav");
      const menuBtn = document.getElementById("menuBtn");
      menuBtn.addEventListener("click", function () {
        const open = nav.classList.toggle("open");
        menuBtn.setAttribute("aria-expanded", String(open));
      });
      document.querySelectorAll("#nav-links a, #nav-links button").forEach(function (el) {
        el.addEventListener("click", function () {
          nav.classList.remove("open");
          menuBtn.setAttribute("aria-expanded", "false");
        });
      });

      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      document.querySelectorAll(".check").forEach(function (el) {
        if (reduce) {
          el.classList.add("show");
          return;
        }
        const delay = Number(el.getAttribute("data-delay") || 0);
        setTimeout(function () { el.classList.add("show"); }, delay);
      });

      const orders = document.getElementById("orders");
      const countries = document.getElementById("countries");
      const ordersOut = document.getElementById("ordersOut");
      const countriesOut = document.getElementById("countriesOut");
      const legalOut = document.getElementById("legalOut");
      const fineOut = document.getElementById("fineOut");

      function fmt(n) { return n.toLocaleString("en-US"); }
      function money(n) { return "$" + fmt(Math.round(n)); }
      function setPct(el) {
        const min = Number(el.min);
        const max = Number(el.max);
        const pct = ((Number(el.value) - min) / (max - min)) * 100;
        el.style.setProperty("--pct", pct + "%");
      }
      function calc() {
        const o = Number(orders.value);
        const c = Number(countries.value);
        ordersOut.textContent = o >= 50000 ? "50,000+" : fmt(o);
        countriesOut.textContent = c >= 50 ? "50+" : String(c);
        setPct(orders);
        setPct(countries);
        const legal = 8000 + o * 1 + c * 250;
        const fines = 20000 + o * 4 + c * 1500;
        legalOut.innerHTML = money(legal) + "<span>/yr</span>";
        if (fines >= 50000) {
          const shown = fines < 75000 ? 50000 : Math.floor(fines / 1000) * 1000;
          fineOut.innerHTML = money(shown) + "<em>+</em>";
        } else {
          fineOut.innerHTML = money(fines);
        }
      }
      orders.addEventListener("input", calc);
      countries.addEventListener("input", calc);
      calc();

      const API_URL = window.ECOCOMPLY_API_URL || "http://localhost:8000/api/audit";
      const modal = document.getElementById("modal");
      const title = document.getElementById("modalTitle");
      const copy = document.getElementById("modalCopy");
      const form = document.getElementById("leadForm");
      const thanks = document.getElementById("thanks");
      const submitBtn = document.getElementById("submitBtn");
      const formError = document.getElementById("formError");
      const resultSummary = document.getElementById("resultSummary");
      const resultOps = document.getElementById("resultOps");
      const downloadReport = document.getElementById("downloadReport");
      let mode = "audit";
      let lastPayload = null;

      function openModal(kind) {
        mode = kind;
        form.classList.remove("hide");
        thanks.classList.remove("show");
        formError.classList.remove("show");
        form.reset();
        form.querySelector('input[value="Shopify"]').checked = true;
        if (kind === "demo") {
          title.textContent = "Book a 15-Min Demo";
          copy.textContent = "See a live scan across EU, US, and UK trade regions with your catalog.";
          submitBtn.textContent = "Request demo";
        } else {
          title.textContent = "Run a free store audit";
          copy.textContent = "We’ll map packaging, shipping lanes, and ESG claims against EU, US, and UK rules.";
          submitBtn.textContent = "Start audit";
        }
        if (typeof modal.showModal === "function") modal.showModal();
      }
      document.querySelectorAll("[data-open]").forEach(function (btn) {
        btn.addEventListener("click", function () { openModal(btn.getAttribute("data-open")); });
      });
      document.getElementById("closeModal").addEventListener("click", function () { modal.close(); });
      document.getElementById("closeThanks").addEventListener("click", function () { modal.close(); });
      downloadReport.addEventListener("click", async function () {
        if (!lastPayload) return;
        downloadReport.disabled = true;
        try {
          const res = await fetch(API_URL + "/report", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(lastPayload)
          });
          if (res.status === 402) {
            window.location.href = "login.html";
            return;
          }
          if (!res.ok) throw new Error("report failed");
          const blob = await res.blob();
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = "audit_report.pdf";
          a.click();
          URL.revokeObjectURL(url);
        } catch (err) {
          formError.textContent = "Could not download the blueprint. Confirm the API is running.";
          formError.classList.add("show");
        } finally {
          downloadReport.disabled = false;
        }
      });
      form.addEventListener("submit", async function (e) {
        e.preventDefault();
        formError.classList.remove("show");
        const tools = Array.from(form.querySelectorAll('input[name="tools"]:checked')).map(function (el) { return el.value; });
        if (!tools.length) {
          formError.textContent = "Select at least one commerce tool.";
          formError.classList.add("show");
          return;
        }
        const payload = {
          company: form.company.value.trim(),
          email: form.email.value.trim(),
          team_size: form.team_size.value,
          tools: mode === "demo" ? tools.concat(["demo-request"]) : tools
        };
        lastPayload = payload;
        submitBtn.disabled = true;
        try {
          const res = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
          });
          if (!res.ok) throw new Error("The API could not save this audit yet.");
          const data = await res.json();
          resultSummary.textContent = data.summary || "Audit stored.";
          resultOps.innerHTML = "";
          (data.opportunities || []).forEach(function (item) {
            const li = document.createElement("li");
            li.textContent = item;
            resultOps.appendChild(li);
          });
          form.classList.add("hide");
          thanks.classList.add("show");
        } catch (err) {
          formError.textContent = "Could not reach the StackSpace API at localhost:8000. Start the FastAPI server, then try again.";
          formError.classList.add("show");
        } finally {
          submitBtn.disabled = false;
        }
      });
    })();
