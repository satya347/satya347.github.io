# StackSpace

Automated ESG and packaging compliance for global e-commerce brands — plus a paid AI workflow audit that stores intake, analyzes the stack, and issues a downloadable blueprint.

This repo is the full product from Phases 1–6, laid out the way the combine-and-deploy guide specifies.

```
ecocomply-ai/
  frontend/          # Vercel
    index.html
    styles.css
    script.js
    login.html
    success.html
    cancel.html
  backend/           # Railway
    main.py
    database.py
    models.py
    schemas.py
    audit_logic.py
    report.py
    billing.py
    requirements.txt
    .env.example
    .gitignore
    Procfile
    metrics.sql
  DEPLOY.md
  GROWTH.md
```

## Local run

**Backend**

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # then fill real keys
uvicorn main:app --reload --port 8000
```

**Frontend**

```bash
cd frontend
python3 -m http.server 5500
```

Open [http://localhost:5500](http://localhost:5500). Keep `ALLOWED_ORIGIN=http://localhost:5500` in `.env`.

## What you still do on your machine

I cannot create these accounts for you. Create them, then paste keys into `backend/.env` (never commit that file):

| Account | Why |
|---|---|
| [GitHub](https://github.com) | Source of truth |
| [Anthropic](https://console.anthropic.com) | Default AI audit (`ANTHROPIC_API_KEY`) |
| [OpenAI](https://platform.openai.com) | Optional AI path (`OPENAI_API_KEY`) |
| [Supabase](https://supabase.com) | Sign up / log in — put URL + anon key in `frontend/login.html` |
| [Stripe](https://stripe.com) test mode | Checkout + webhooks. Test card `4242 4242 4242 4242` only |
| [Vercel](https://vercel.com) | Hosts `frontend/` |
| [Railway](https://railway.app) | Hosts `backend/` + Postgres |

Then follow **DEPLOY.md**.

## AI provider

Default is Anthropic Claude (`LLM_PROVIDER=anthropic`). To use OpenAI instead:

```
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4.1-mini
```

Do not set `OPENAI_MODEL=gpt-6-astra` for every audit — it is too expensive for this JSON job. Use it later only for a premium deep-audit tier.

## Product flow

1. Visitor runs a free audit on the landing page
2. API stores the intake and returns AI analysis
3. Account + Stripe subscription unlocks the PDF blueprint
4. Internal metrics (`GET /api/internal/metrics` + `X-Metrics-Token`) track MRR and conversion

## Growth

See **GROWTH.md**. A top company is built from paying users, retention, and a weekly ship–watch–fix loop — not from more files.
