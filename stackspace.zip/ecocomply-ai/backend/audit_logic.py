# audit_logic.py — the core "intelligence" of the product
import os
import json
from dotenv import load_dotenv

load_dotenv()

SYSTEM_PROMPT = """You are an operations consultant analyzing a company's software \
stack to find AI/automation ROI opportunities.

Given a list of tools a company uses, return ONLY valid JSON in this exact shape,
with no other text before or after:

{
    "summary": "2-3 sentence plain-English summary of their overall setup",
    "opportunities": ["specific automation opportunity 1", "opportunity 2", "..."],
    "redundant_tools": ["tool or overlap 1", "tool or overlap 2", "..."]
}

Rules:
- opportunities should be specific and actionable, not generic advice
- redundant_tools should flag genuine overlap (e.g. two tools doing the same job),
  not just list every tool
- if the tool list is short or unclear, say so honestly in summary rather than
  inventing detail
- return 3-6 opportunities and 0-4 redundant_tools items
- never invent tools that were not in the provided list
"""

FALLBACK = {
    "summary": "We had trouble analyzing this stack. Please try again.",
    "opportunities": [],
    "redundant_tools": [],
}


def _parse_json(raw_text: str) -> dict:
    raw_text = raw_text.strip().replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(raw_text)
    except json.JSONDecodeError:
        return FALLBACK


def _placeholder(tools_str: str) -> dict:
    return {
        "summary": (
            f"Stack received: {tools_str or 'none listed'}. "
            "Add ANTHROPIC_API_KEY or OPENAI_API_KEY to .env to generate a live AI audit."
        ),
        "opportunities": [
            "Connect an API key to unlock live stack analysis",
            "Map overlapping support, CRM, and commerce tools once the key is set",
            "Generate a downloadable workflow blueprint from the live result",
        ],
        "redundant_tools": [],
    }


def _run_anthropic(tools_str: str) -> dict:
    import anthropic

    client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
    response = client.messages.create(
        model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6"),
        max_tokens=1000,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": f"Company's current tools: {tools_str}"}],
    )
    return _parse_json(response.content[0].text)


def _run_openai(tools_str: str) -> dict:
    from openai import OpenAI

    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
    response = client.chat.completions.create(
        model=model,
        temperature=0.2,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Company's current tools: {tools_str}"},
        ],
    )
    return _parse_json(response.choices[0].message.content or "")


def run_audit(tools: list[str]) -> dict:
    tools_str = ", ".join(tools)
    provider = (os.getenv("LLM_PROVIDER") or "anthropic").strip().lower()

    has_anthropic = bool(os.getenv("ANTHROPIC_API_KEY"))
    has_openai = bool(os.getenv("OPENAI_API_KEY"))

    if provider == "openai":
        if not has_openai:
            return _placeholder(tools_str)
        return _run_openai(tools_str)

    if has_anthropic:
        return _run_anthropic(tools_str)
    if has_openai:
        return _run_openai(tools_str)
    return _placeholder(tools_str)
