# main.py — the API itself
from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from sqlalchemy.orm import Session
import os
import stripe
from dotenv import load_dotenv

from database import engine, get_db, Base
from schemas import AuditIn, AuditOut
import models
from audit_logic import run_audit
from report import generate_report_pdf
from billing import create_checkout_session

load_dotenv()

Base.metadata.create_all(bind=engine)

app = FastAPI(title="StackSpace API")

# Tighten CORS for production (was "*" during dev)
_allowed = os.getenv("ALLOWED_ORIGIN", "*")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in _allowed.split(",") if origin.strip()],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET")
PUBLIC_SITE = os.getenv("PUBLIC_SITE_URL", "http://localhost:5500")
METRICS_TOKEN = os.getenv("METRICS_TOKEN", "change-me")


def upsert_user(db: Session, email: str, company: str | None = None):
    user = db.query(models.User).filter_by(email=email).first()
    if not user:
        user = models.User(email=email, company=company or "")
        db.add(user)
        db.commit()
        db.refresh(user)
    elif company and not user.company:
        user.company = company
        db.commit()
    return user


def require_metrics_token(request: Request):
    token = request.headers.get("x-metrics-token")
    if token != METRICS_TOKEN:
        raise HTTPException(status_code=401, detail="Unauthorized")


def record_payment(
    db: Session,
    *,
    email: str | None,
    amount_cents: int,
    currency: str,
    status: str,
    stripe_event_id: str,
    stripe_object_id: str | None,
    description: str,
):
    existing = db.query(models.Payment).filter_by(stripe_event_id=stripe_event_id).first()
    if existing:
        return existing
    row = models.Payment(
        email=email,
        amount_cents=amount_cents or 0,
        currency=(currency or "usd").lower(),
        status=status,
        stripe_event_id=stripe_event_id,
        stripe_object_id=stripe_object_id,
        description=description,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@app.get("/")
def health_check():
    return {"status": "ok", "company": "StackSpace"}


@app.get("/api/internal/metrics")
def get_metrics(request: Request, db: Session = Depends(get_db)):
    require_metrics_token(request)
    total_users = db.query(models.User).count()
    subscribed = db.query(models.User).filter_by(is_subscribed=True).count()
    total_audits = db.query(models.AuditRequest).count()
    collected = (
        db.query(models.Payment)
        .filter(models.Payment.status.in_(["succeeded", "paid"]))
        .all()
    )
    collected_cents = sum(p.amount_cents or 0 for p in collected)
    return {
        "total_users": total_users,
        "active_subscribers": subscribed,
        "mrr_usd": subscribed * 29,
        "money_collected_usd": round(collected_cents / 100, 2),
        "payments_recorded": len(collected),
        "total_audits_run": total_audits,
        "conversion_rate": round(subscribed / total_users, 3) if total_users else 0,
    }


@app.get("/api/internal/payments")
def list_payments(request: Request, db: Session = Depends(get_db)):
    require_metrics_token(request)
    rows = db.query(models.Payment).order_by(models.Payment.id.desc()).limit(100).all()
    return {
        "payments": [
            {
                "id": p.id,
                "email": p.email,
                "amount_usd": round((p.amount_cents or 0) / 100, 2),
                "currency": p.currency,
                "status": p.status,
                "description": p.description,
                "stripe_object_id": p.stripe_object_id,
                "created_at": p.created_at.isoformat() if p.created_at else None,
            }
            for p in rows
        ]
    }


@app.post("/api/audit", response_model=AuditOut)
def create_audit(payload: AuditIn, db: Session = Depends(get_db)):
    result = run_audit(payload.tools)
    upsert_user(db, payload.email, payload.company)

    record = models.AuditRequest(
        company=payload.company,
        email=payload.email,
        team_size=payload.team_size,
        tools=", ".join(payload.tools),
        summary=result["summary"],
        opportunities="\n".join(result["opportunities"]),
        redundant_tools="\n".join(result["redundant_tools"]),
    )
    db.add(record)
    db.commit()

    return AuditOut(**result)


@app.post("/api/audit/report")
def download_report(payload: AuditIn, db: Session = Depends(get_db)):
    user = db.query(models.User).filter_by(email=payload.email).first()
    if not user or not user.is_subscribed:
        raise HTTPException(status_code=402, detail="Subscription required")

    result = run_audit(payload.tools)
    pdf_bytes = generate_report_pdf(payload.company, result)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": "attachment; filename=audit_report.pdf"},
    )


@app.post("/api/billing/checkout")
def start_checkout(email: str, db: Session = Depends(get_db)):
    upsert_user(db, email)
    url = create_checkout_session(
        customer_email=email,
        success_url=f"{PUBLIC_SITE}/success.html",
        cancel_url=f"{PUBLIC_SITE}/cancel.html",
    )
    return {"checkout_url": url}


@app.post("/api/billing/webhook")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    try:
        event = stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)
    except (ValueError, stripe.error.SignatureVerificationError):
        return Response(status_code=400)

    obj = event["data"]["object"]
    event_id = event.get("id")
    customer_email = obj.get("customer_email") or obj.get("email")

    if not customer_email and obj.get("customer"):
        try:
            customer = stripe.Customer.retrieve(obj["customer"])
            customer_email = customer.get("email")
        except Exception:
            customer_email = None

    if event["type"] == "checkout.session.completed":
        if customer_email:
            user = upsert_user(db, customer_email)
            user.is_subscribed = True
            if obj.get("customer"):
                user.stripe_customer_id = str(obj["customer"])
            db.commit()
        record_payment(
            db,
            email=customer_email,
            amount_cents=int(obj.get("amount_total") or 0),
            currency=obj.get("currency") or "usd",
            status="succeeded",
            stripe_event_id=event_id,
            stripe_object_id=obj.get("id"),
            description="Stripe Checkout subscription payment",
        )

    elif event["type"] == "invoice.paid":
        record_payment(
            db,
            email=customer_email,
            amount_cents=int(obj.get("amount_paid") or 0),
            currency=obj.get("currency") or "usd",
            status="paid",
            stripe_event_id=event_id,
            stripe_object_id=obj.get("id"),
            description="Stripe invoice payment",
        )
        if customer_email:
            user = upsert_user(db, customer_email)
            user.is_subscribed = True
            db.commit()

    elif event["type"] == "customer.subscription.created":
        if customer_email:
            user = upsert_user(db, customer_email)
            user.is_subscribed = True
            if obj.get("customer"):
                user.stripe_customer_id = str(obj["customer"])
            db.commit()

    elif event["type"] == "customer.subscription.deleted":
        if customer_email:
            user = db.query(models.User).filter_by(email=customer_email).first()
            if user:
                user.is_subscribed = False
                db.commit()

    return {"status": "received"}
