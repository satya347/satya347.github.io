-- Run against your Postgres database to see real business health

-- Monthly Recurring Revenue (MRR)
SELECT COUNT(*) * 29 AS mrr_usd    -- 29 = your monthly price
FROM users
WHERE is_subscribed = true;

-- Active subscriber count
SELECT COUNT(*) FROM users WHERE is_subscribed = true;

-- Audits run per week (engagement)
SELECT DATE_TRUNC('week', created_at) AS week, COUNT(*) AS audits
FROM audit_requests
GROUP BY week
ORDER BY week DESC;

-- Signup-to-paid conversion rate
SELECT
  (SELECT COUNT(*) FROM users WHERE is_subscribed = true)::float
  / NULLIF((SELECT COUNT(*) FROM users), 0) AS conversion_rate;
