# report.py — turn an audit result into a downloadable PDF blueprint
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
import io


def generate_report_pdf(company: str, result: dict) -> bytes:
    """Returns PDF bytes — can be sent directly as an HTTP response."""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        topMargin=0.8 * inch,
        bottomMargin=0.8 * inch,
    )
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="ReportTitle",
            fontSize=20,
            textColor=colors.HexColor("#0F5132"),
            fontName="Helvetica-Bold",
            spaceAfter=10,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Section",
            fontSize=13,
            spaceBefore=14,
            spaceAfter=6,
            fontName="Helvetica-Bold",
        )
    )

    story = [
        Paragraph(f"AI Workflow Audit — {company}", styles["ReportTitle"]),
        Paragraph(result["summary"], styles["Normal"]),
        Spacer(1, 0.1 * inch),
        Paragraph("Automation Opportunities", styles["Section"]),
    ]
    for item in result["opportunities"]:
        story.append(Paragraph(f"• {item}", styles["Normal"]))

    story.append(Paragraph("Redundant / Overlapping Tools", styles["Section"]))
    if result["redundant_tools"]:
        for item in result["redundant_tools"]:
            story.append(Paragraph(f"• {item}", styles["Normal"]))
    else:
        story.append(Paragraph("None identified.", styles["Normal"]))

    doc.build(story)
    return buffer.getvalue()
