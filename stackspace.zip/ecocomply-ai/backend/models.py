# models.py — database tables
from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean
from sqlalchemy.sql import func
from database import Base


class AuditRequest(Base):
    __tablename__ = "audit_requests"

    id = Column(Integer, primary_key=True, index=True)
    company = Column(String, nullable=False)
    email = Column(String, nullable=False, index=True)
    team_size = Column(String)
    tools = Column(Text)  # stored as comma-separated string
    summary = Column(Text)
    opportunities = Column(Text)  # stored as newline-separated
    redundant_tools = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, nullable=False, index=True)
    company = Column(String)
    is_subscribed = Column(Boolean, default=False)
    stripe_customer_id = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Payment(Base):
    """Ledger of money received from subscribers. Cash lives in Stripe; this table is the company record."""

    __tablename__ = "payments"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, index=True)
    amount_cents = Column(Integer, nullable=False, default=0)
    currency = Column(String, default="usd")
    status = Column(String, default="succeeded")
    stripe_event_id = Column(String, unique=True, index=True)
    stripe_object_id = Column(String, index=True)
    description = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
