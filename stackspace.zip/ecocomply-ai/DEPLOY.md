# Deploy StackSpace

Front end and backend must know each other's real URLs.

## 1. Push to GitHub

From this folder (`ecocomply-ai/`):

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/yourusername/ecocomply-ai.git
git push -u origin main
```

Never commit `backend/.env`.

## 2. Vercel (frontend)

- Import the GitHub repo
- Framework: **Other**
- Root directory: **frontend**
- Deploy → `https://your-app.vercel.app`

## 3. Railway (backend)

- New project → deploy from GitHub
- Root directory: **backend**
- Add variables from `backend/.env.example`:
  `DATABASE_URL`, `ANTHROPIC_API_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_ID`, `ALLOWED_ORIGIN`, `PUBLIC_SITE_URL`, `METRICS_TOKEN`
- `Procfile` starts: `uvicorn main:app --host 0.0.0.0 --port $PORT`

## 4. Postgres

Railway → New → Database → PostgreSQL → paste connection string into `DATABASE_URL`.

## 5. Point the frontend at Railway

In `frontend/script.js`:

```js
window.ECOCOMPLY_API_URL = "https://YOUR-API.up.railway.app/api/audit";
```

Set `ALLOWED_ORIGIN=https://your-app.vercel.app` and `PUBLIC_SITE_URL=https://your-app.vercel.app` on Railway. Push so Vercel redeploys.

## 6. Stripe webhook

`https://YOUR-API.up.railway.app/api/billing/webhook`

Copy the signing secret into `STRIPE_WEBHOOK_SECRET`.

## Launch checklist

- [ ] Site live
- [ ] No CORS errors
- [ ] Postgres, not SQLite
- [ ] Webhook live
- [ ] Secrets only in dashboards
- [ ] Sign up → subscribe → audit → download report
