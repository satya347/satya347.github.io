# Growth, metrics, and funding

Track these every week:

- **MRR** = subscribed users × $29
- **Active subscribers**
- **Audits per week**
- **Signup-to-paid conversion**

SQL: `backend/metrics.sql`  
API: `GET /api/internal/metrics` with header `X-Metrics-Token`

Ten engaged users beat a thousand passive signups. Watch drop-off, fix the worst friction, ship, watch again.

Investors fund evidence: paying customers, retention, a clear use of capital.

When revenue is real: incorporate with a lawyer/accountant, open a business bank account, keep personal money out of it.
