# EcoComply AI — Backend (Phases 2–3)

FastAPI service that receives audit form data, stores it, runs AI analysis, and returns a PDF blueprint.

## Setup

```bash
cd ecocomply-backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Set `ANTHROPIC_API_KEY` in `.env` (from console.anthropic.com). Without a real key, `/api/audit` still returns a safe placeholder so the form does not crash.

```
DATABASE_URL=sqlite:///./ecocomply.db
ALLOWED_ORIGIN=http://localhost:5500
ANTHROPIC_API_KEY=your_key_here
```

## Run

```bash
uvicorn main:app --reload --port 8000
```

Serve the landing page on port 5500 so CORS matches `ALLOWED_ORIGIN`.

## Endpoints

- `GET /` health check
- `POST /api/audit` stores the intake and returns `{summary, opportunities, redundant_tools}`
- `POST /api/audit/report` returns `audit_report.pdf`

```bash
curl -X POST http://localhost:8000/api/audit \
  -H "Content-Type: application/json" \
  -d '{"company":"Acme","email":"a@acme.com","team_size":"11-50","tools":["Zendesk","Salesforce"]}'
```
