# audit_logic.py — the core "intelligence" of the product
import os
import json
import anthropic
from dotenv import load_dotenv

load_dotenv()

client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

SYSTEM_PROMPT = """You are an operations consultant analyzing a company's software \
stack to find AI/automation ROI opportunities.

Given a list of tools a company uses, return ONLY valid JSON in this exact shape,
with no other text before or after:

{
    "summary": "2-3 sentence plain-English summary of their overall setup",
    "opportunities": ["specific automation opportunity 1", "opportunity 2", "..."],
    "redundant_tools": ["tool or overlap 1", "tool or overlap 2", "..."]
}

Rules:
- opportunities should be specific and actionable, not generic advice
- redundant_tools should flag genuine overlap (e.g. two tools doing the same job),
  not just list every tool
- if the tool list is short or unclear, say so honestly in summary rather than
  inventing detail
- return 3-6 opportunities and 0-4 redundant_tools items
- never invent tools that were not in the provided list
"""


def run_audit(tools: list[str]) -> dict:
    tools_str = ", ".join(tools)

    if not os.getenv("ANTHROPIC_API_KEY"):
        return {
            "summary": (
                f"Stack received: {tools_str or 'none listed'}. "
                "Add ANTHROPIC_API_KEY to .env to generate a live AI audit."
            ),
            "opportunities": [
                "Connect an Anthropic API key to unlock live stack analysis",
                "Map overlapping support, CRM, and commerce tools once the key is set",
                "Generate a downloadable workflow blueprint from the live result",
            ],
            "redundant_tools": [],
        }

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1000,
        system=SYSTEM_PROMPT,
        messages=[
            {"role": "user", "content": f"Company's current tools: {tools_str}"}
        ],
    )

    raw_text = response.content[0].text.strip()

    # Defensive parsing — LLMs occasionally wrap JSON in markdown fences
    raw_text = raw_text.replace("```json", "").replace("```", "").strip()

    try:
        result = json.loads(raw_text)
    except json.JSONDecodeError:
        # Fallback so the API never hard-crashes on a malformed response
        result = {
            "summary": "We had trouble analyzing this stack. Please try again.",
            "opportunities": [],
            "redundant_tools": [],
        }

    return result
