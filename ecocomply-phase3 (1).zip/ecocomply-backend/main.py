# main.py — the API itself
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from sqlalchemy.orm import Session
import os

from database import engine, get_db, Base
from schemas import AuditIn, AuditOut
import models
from audit_logic import run_audit
from report import generate_report_pdf

Base.metadata.create_all(bind=engine)

app = FastAPI(title="EcoComply-AI API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[os.getenv("ALLOWED_ORIGIN", "*")],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def health_check():
    return {"status": "ok"}


@app.post("/api/audit", response_model=AuditOut)
def create_audit(payload: AuditIn, db: Session = Depends(get_db)):
    result = run_audit(payload.tools)  # -> {summary, opportunities, redundant_tools}

    record = models.AuditRequest(
        company=payload.company,
        email=payload.email,
        team_size=payload.team_size,
        tools=", ".join(payload.tools),
        summary=result["summary"],
        opportunities="\n".join(result["opportunities"]),
        redundant_tools="\n".join(result["redundant_tools"]),
    )
    db.add(record)
    db.commit()

    return AuditOut(**result)


@app.post("/api/audit/report")
def download_report(payload: AuditIn):
    result = run_audit(payload.tools)
    pdf_bytes = generate_report_pdf(payload.company, result)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": "attachment; filename=audit_report.pdf"},
    )
