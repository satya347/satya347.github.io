# models.py — database tables
from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean
from sqlalchemy.sql import func
from database import Base


class AuditRequest(Base):
    __tablename__ = "audit_requests"

    id = Column(Integer, primary_key=True, index=True)
    company = Column(String, nullable=False)
    email = Column(String, nullable=False, index=True)
    team_size = Column(String)
    tools = Column(Text)  # stored as comma-separated string
    summary = Column(Text)
    opportunities = Column(Text)  # stored as newline-separated
    redundant_tools = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, nullable=False, index=True)
    company = Column(String)
    is_subscribed = Column(Boolean, default=False)
    stripe_customer_id = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
