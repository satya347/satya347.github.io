# EcoComply AI — Phase 2 Backend

FastAPI service that receives audit form data from the landing page, stores it, and returns a structured response.

## Setup

```bash
cd ecocomply-backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

`.env` defaults to SQLite so you can run locally without Postgres:

```
DATABASE_URL=sqlite:///./ecocomply.db
ALLOWED_ORIGIN=http://localhost:5500
```

For Postgres, set `DATABASE_URL=postgresql://user:password@localhost:5432/ecocomply`.

## Run

```bash
uvicorn main:app --reload --port 8000
```

Serve the landing page on port 5500 (VS Code Live Server or `python3 -m http.server 5500`) so CORS matches `ALLOWED_ORIGIN`.

## Test

```bash
curl -X POST http://localhost:8000/api/audit \
  -H "Content-Type: application/json" \
  -d '{"company":"Acme","email":"a@acme.com","team_size":"11-50","tools":["Zendesk","Salesforce"]}'
```

`audit_logic.py` is a Phase 2 stub. Phase 3 replaces it with product intelligence.
