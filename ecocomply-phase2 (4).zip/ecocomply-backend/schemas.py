# schemas.py — request/response shapes (Pydantic)
from pydantic import BaseModel, EmailStr
from typing import List


class AuditIn(BaseModel):
    company: str
    email: EmailStr
    team_size: str
    tools: List[str]


class AuditOut(BaseModel):
    summary: str
    opportunities: List[str]
    redundant_tools: List[str]
