# Phase 5 — Deployment

Free tiers (Vercel, Railway) are enough to launch. Follow in order — front end and backend need each other's real URLs.

## 1. Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/yourusername/ecocomply-ai.git
git push -u origin main
```

Never commit `.env`.

## 2. Deploy the front end (Vercel)

- vercel.com → Import Project → your GitHub repo
- Framework preset: **Other** (plain HTML/CSS/JS)
- Deploy — you get a URL like `ecocomply-ai.vercel.app`

## 3. Deploy the backend (Railway)

- railway.app → New Project → Deploy from GitHub repo
- Root directory: `ecocomply-backend` (or deploy that folder as the service)
- Add env vars from `.env`:
  `DATABASE_URL`, `ANTHROPIC_API_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `STRIPE_PRICE_ID`, `ALLOWED_ORIGIN`, `PUBLIC_SITE_URL`
- Railway uses the `Procfile`: `web: uvicorn main:app --host 0.0.0.0 --port $PORT`
- You get a URL like `ecocomply-api.up.railway.app`

## 4. Managed Postgres

- Railway → New → Database → PostgreSQL
- Copy the connection string into `DATABASE_URL`

## 5. Update the front end

In `script.js`, set:

```js
window.ECOCOMPLY_API_URL = "https://ecocomply-api.up.railway.app/api/audit";
```

Push to GitHub so Vercel re-deploys.

## 6. Stripe webhooks

- Stripe Dashboard → Developers → Webhooks → Add endpoint
- URL: `https://ecocomply-api.up.railway.app/api/billing/webhook`
- Copy the signing secret into `STRIPE_WEBHOOK_SECRET` on Railway

## Custom domain (optional)

1. Buy a domain
2. Vercel → Project Settings → Domains
3. Wait for DNS
4. Set `ALLOWED_ORIGIN=https://yourdomain.com` and `PUBLIC_SITE_URL=https://yourdomain.com` on Railway

## Launch checklist

- [ ] Front end live at your domain
- [ ] Backend reachable from the front end (no CORS errors)
- [ ] Database is managed Postgres, not local SQLite
- [ ] Stripe webhook pointed at the live backend URL
- [ ] Secrets set in Railway/Vercel dashboards, not GitHub
- [ ] Full flow: sign up → subscribe → run audit → download report
