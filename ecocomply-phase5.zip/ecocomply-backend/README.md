# EcoComply AI — Phases 1–5

Landing page + FastAPI + AI audit + PDF blueprint + Supabase auth + Stripe + deploy config.

## Local run

```bash
cd ecocomply-backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

In another terminal, from the folder that contains the HTML files:

```bash
python3 -m http.server 5500
```

Open `http://localhost:5500/ecocomply-ai.html`.

## Live deploy

See `DEPLOY.md` (Phase 5): GitHub → Vercel (front end) → Railway (API + Postgres) → Stripe webhook.

After Railway gives you a URL, set it in `script.js`:

```js
window.ECOCOMPLY_API_URL = "https://ecocomply-api.up.railway.app/api/audit";
```

Set `ALLOWED_ORIGIN` to your Vercel/custom domain. Do not commit `.env`.
