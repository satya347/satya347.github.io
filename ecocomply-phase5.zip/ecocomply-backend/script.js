// script.js — change API_URL to your live Railway backend after deploy
window.ECOCOMPLY_API_URL = window.ECOCOMPLY_API_URL || "http://localhost:8000/api/audit";
